#include <iostream>
using namespace std;
int main() {
    
    
    for (int counter = 1;counter<=10;counter++){
      cout<< "The value of counter is "<<counter <<endl; 
        
    }
    return 0;
}
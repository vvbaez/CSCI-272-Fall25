
#include <iostream>
using namespace std;
int main()
{
    int sum=0;
   int num_arr[7] = {6,8,7,4,2,1,9};
   
    for(int i=0; i<7; i++){
     sum += num_arr[i] ;
    }
    cout<<sum<<endl;
    return 0;
}
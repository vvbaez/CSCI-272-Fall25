

#include <iostream>
#include <cstdlib>
using namespace std;

int main (){
    int high = 6;
    int low = 1;
     //seed initial value in random number generator
    srand(time(NULL)); ///time(null gives difference between first date till when botton clicked)
    cout<<rand()%(high-low)+low;
  //  cout<<rand()%(6-1)+1+1 ; ////extracts one digit
    return 0;
}